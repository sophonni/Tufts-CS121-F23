package jrails;

public class Html {
    public String toString() {
        throw new UnsupportedOperationException();
    }

    public Html seq(Html h) {
        throw new UnsupportedOperationException();
    }

    public Html br() {
        throw new UnsupportedOperationException();
    }

    public Html t(Object o) {
        // Use o.toString() to get the text for this
        throw new UnsupportedOperationException();
    }

    public Html p(Html child) {
        throw new UnsupportedOperationException();
    }

    public Html div(Html child) {
        throw new UnsupportedOperationException();
    }

    public Html strong(Html child) {
        throw new UnsupportedOperationException();
    }

    public Html h1(Html child) {
        throw new UnsupportedOperationException();
    }

    public Html tr(Html child) {
        throw new UnsupportedOperationException();
    }

    public Html th(Html child) {
        throw new UnsupportedOperationException();
    }

    public Html td(Html child) {
        throw new UnsupportedOperationException();
    }

    public Html table(Html child) {
        throw new UnsupportedOperationException();
    }

    public Html thead(Html child) {
        throw new UnsupportedOperationException();
    }

    public Html tbody(Html child) {
        throw new UnsupportedOperationException();
    }

    public Html textarea(String name, Html child) {
        throw new UnsupportedOperationException();
    }

    public Html link_to(String text, String url) {
        throw new UnsupportedOperationException();
    }

    public Html form(String action, Html child) {
        throw new UnsupportedOperationException();
    }

    public Html submit(String value) {
        throw new UnsupportedOperationException();
    }
}