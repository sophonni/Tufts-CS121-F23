package jrails;

public class View {
    public static Html empty() {
        throw new UnsupportedOperationException();
    }

    public static Html br() {
        throw new UnsupportedOperationException();
    }

    public static Html t(Object o) {
        // Use o.toString() to get the text for this
        throw new UnsupportedOperationException();
    }

    public static Html p(Html child) {
        throw new UnsupportedOperationException();
    }

    public static Html div(Html child) {
        throw new UnsupportedOperationException();
    }

    public static Html strong(Html child) {
        throw new UnsupportedOperationException();
    }

    public static Html h1(Html child) {
        throw new UnsupportedOperationException();
    }

    public static Html tr(Html child) {
        throw new UnsupportedOperationException();
    }

    public static Html th(Html child) {
        throw new UnsupportedOperationException();
    }

    public static Html td(Html child) {
        throw new UnsupportedOperationException();
    }

    public static Html table(Html child) {
        throw new UnsupportedOperationException();
    }

    public static Html thead(Html child) {
        throw new UnsupportedOperationException();
    }

    public static Html tbody(Html child) {
        throw new UnsupportedOperationException();
    }

    public static Html textarea(String name, Html child) {
        throw new UnsupportedOperationException();
    }

    public static Html link_to(String text, String url) {
        throw new UnsupportedOperationException();
    }

    public static Html form(String action, Html child) {
        throw new UnsupportedOperationException();
    }

    public static Html submit(String value) {
        throw new UnsupportedOperationException();
    }
}